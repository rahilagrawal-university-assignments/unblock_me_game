/**
 * enum to hold various values for difficulty (easy, medium, hard)
 */
public enum Difficulty {
	Easy, Medium, Hard
}

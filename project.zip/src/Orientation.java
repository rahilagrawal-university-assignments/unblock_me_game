/**
 * enum to hold orientations
 */
public enum Orientation {
    Vertical, Horizontal
}
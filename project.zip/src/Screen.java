/**
 * enum to hold various screen options, used for changing screens in GameRunner
 */
public enum Screen {
	Main, Leaderboard, Grid, Finished, LevelSelect
}

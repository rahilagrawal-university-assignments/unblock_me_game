/**
 * enum for type of vehicle (car or truck)
 */
public enum Type {
    Car, Truck
}